<div align="center">

# ✦ Skilldom

### Discover yourself. Explore new skills. Grow at your own pace.

**A friendly little space for curious minds and big ideas.**

![Made with HTML](https://img.shields.io/badge/HTML-5-e67e44?style=for-the-badge&logo=html5&logoColor=white)
![Made with CSS](https://img.shields.io/badge/CSS-3-2894d1?style=for-the-badge&logo=css3&logoColor=white)
![Made with JavaScript](https://img.shields.io/badge/JavaScript-vanilla-f6d64b?style=for-the-badge&logo=javascript&logoColor=black)
![Beginner Friendly](https://img.shields.io/badge/Beginner-Friendly-68d8ab?style=for-the-badge)

**[🌱 Try Skilldom](./index.html)** · **[✨ Explore features](#-what-can-you-do)** · **[🚀 Get started](#-run-it-yourself)**

</div>

---

## 🌍 What is Skilldom?

**Skilldom** is a beginner-friendly project about self-discovery and learning.

You don't need to know your future or be an expert at anything. Sometimes all you need is one idea, one experiment, and one small step forward.

> **Find what excites you. Try something new. Keep growing.**

## ✨ What can you do?

| Feature | What's inside |
| :--- | :--- |
| 🎨 Explore skills | Find interesting directions, from art to coding. |
| 🧭 Mini skill finder | Answer five fun questions for an idea of what to try next. |
| ✅ Personal goals | Add goals and tick them off as you go. |
| 📱 Responsive layout | Works on phones, tablets, and computers. |
| 🔒 Local goal storage | Goals stay in your own browser, with no account required. |

**Note:** The skill finder is just for inspiration; it's not a scientific personality or career assessment.

## 🚀 Run it yourself

No installation or frameworks needed!

1. Download this repository or clone it:
   ```bash
   git clone https://github.com/Princerepdo/Skilldom.git
   ```
2. Open the `index.html` file in a web browser.
3. Explore the page, try the quiz, and add a goal. 🎉

## 🌐 Put it online with GitHub Pages

1. Open this repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select **main** and **/(root)**, then choose **Save**.
5. GitHub will show your live website link on the Pages settings screen after publishing.

## 🗂️ Project structure

```text
Skilldom/
├── README.md      # Project information
└── index.html     # Complete interactive website
```

## 💡 Ideas for the future

- [x] Build the first Skilldom website
- [x] Add an interactive skill finder
- [x] Let users track simple goals
- [ ] Add more interests and skill paths
- [ ] Add a light / dark theme switch
- [ ] Add beginner learning challenges
- [ ] Improve accessibility and test with more users

## 🤝 Contributing

Have a suggestion? Open an **Issue** with your idea. Friendly feedback and first-time contributors are welcome!

## ⭐ Support Skilldom

If you like the idea, consider giving this repository a star. It helps me know people find it useful.

---

<div align="center">

**Made with curiosity and a belief that everyone can learn something new. 🌱**

*Your journey starts with a single step.*

</div>
